<?php $__env->startSection('content'); ?>
<div class="container">
	 <?php if(session('successMsg')): ?>
        <div class="alert alert-dismissible alert-success">
  <button type="button" class="close" data-dismiss="alert">×</button>
  <?php echo e(session('successMsg')); ?>

</div>
	 <?php endif; ?>

	 <table class="table table-bordered table-striped table-hover ">
  <thead>
  <tr>
    <th>ID</th>
    <th>First Nmae</th>
    <th>Last Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th class="text-center">Action</th>
  </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
   <td><?php echo e($student->id); ?></td>
   <td><?php echo e($student->first_name); ?></td>
   <td><?php echo e($student->last_name); ?></td>
   <td><?php echo e($student->email); ?></td>
   <td><?php echo e($student->phone); ?></td>
   <td class="text-center"><a class="btn btn-raised btn-success btn-sm" href="<?php echo e(route('edit',$student->id)); ?>"><i class="far fa-edit"></i></a> ||

                <form method="POST" id="delete-form-<?php echo e($student->id); ?>" action=<?php echo e(route('delete',$student->id)); ?>" style="display:none;">
                	<?php echo e(csrf_field()); ?>

                	<?php echo e(method_field('delete')); ?>

                	
                </form>
                	<button onclick="if(confirm('Are you Sure?You Delete this?')){
                		  event.preventDefault();
                         document.getElementById('delete-form-<?php echo e($student->id); ?>').submit();
                      }else{
                         	event.preventDefault();
                         }" class="btn btn-raised btn-danger btn-sm"><i class="far fa-trash-alt"></i></button>
				  </tr>
				  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				</table>
				</div>
				<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>