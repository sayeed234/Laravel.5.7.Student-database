<?php $__env->startSection('content'); ?>
<div class="container">
	<?php if($errors->any()): ?>
	  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-dismissible alert-danger">
  <button type="button" class="close" data-dismiss="alert">×</button>
  <?php echo e($error); ?>

</div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  <?php endif; ?>
	<div class="panel panel-default">
		<div class="panel-heading">
                <h3 class="panel-title">Add New Student</h3>			
		</div>
		<div class="panel-body">
			<form class="form-horizontal" action="<?php echo e(route('update',$student->id)); ?>" method="POST">
				<?php echo e(csrf_field()); ?>

  <fieldset>
    <legend>Please Entry your Contact</legend>
    <div class="form-group">
      <label for="firstname" class="col-md-2 control-label">First Name</label>

      <div class="col-md-10">
        <input type="text" class="form-control" value="<?php echo e($student->first_name); ?>" name="firstname" placeholder="First Name">
      </div>

  </div>
      <div class="form-group">
      <label for="lastname" class="col-md-2 control-label">Last Name</label>

      <div class="col-md-10">
        <input type="text" class="form-control"value="<?php echo e($student->last_name); ?>" name="lastname" placeholder="Last Name">
      
    </div>
</div>
     <div class="form-group">
      <label for="inputEmail" class="col-md-2 control-label">Email</label>

      <div class="col-md-10">
        <input type="email" class="form-control" value="<?php echo e($student->email); ?>"name="email" id="inputEmail" placeholder="Example@sayeed">
      
    </div>
</div>
    <div class="form-group">
      <label for="phone" class="col-md-2 control-label">Phone Number</label>

      <div class="col-md-10">
        <input type="text" class="form-control" value="<?php echo e($student->phone); ?>"name="phone" placeholder="+880">
      </div>
  </div>
    
    <div class="form-group">
      <div class="col-md-10 col-md-offset-2">
        <button type="button" class="btn btn-default">Cancel</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </fieldset>
</form>
		</div>
	</div>
	
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>